---
sourceFile: "Prompting best practices - Claude API Docs"
exportedBy: "Kortex"
exportDate: "2026-05-17T23:37:51.907Z"
---

# Prompting best practices - Claude API Docs

9de97808-9fab-4d3f-b6f4-545d1484c242

Prompting best practices - Claude API Docs

c2eb59ff-bbc0-4a46-a29a-dc72bc9b20be

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices

Prompting best practices - Claude API Docs

https://platform.claude.com/docs/en/home

Developer Guide

https://platform.claude.com/docs/en/intro

API Reference

https://platform.claude.com/docs/en/api/overview

https://modelcontextprotocol.io/

https://platform.claude.com/docs/en/resources/overview

Release Notes

https://platform.claude.com/docs/en/release-notes/overview

https://platform.claude.com/login?returnTo=%2Fdocs%2Fen%2Fbuild-with-claude%2Fprompt-engineering%2Fclaude-prompting-best-practices

First steps

Intro to Claude

https://platform.claude.com/docs/en/intro

https://platform.claude.com/docs/en/get-started

Models & pricing

Models overview

https://platform.claude.com/docs/en/about-claude/models/overview

Choosing a model

https://platform.claude.com/docs/en/about-claude/models/choosing-a-model

What's new in Claude 4.6

https://platform.claude.com/docs/en/about-claude/models/whats-new-claude-4-6

Migration guide

https://platform.claude.com/docs/en/about-claude/models/migration-guide

Model deprecations

https://platform.claude.com/docs/en/about-claude/model-deprecations

https://platform.claude.com/docs/en/about-claude/pricing

Build with Claude

Features overview

https://platform.claude.com/docs/en/build-with-claude/overview

Using the Messages API

https://platform.claude.com/docs/en/build-with-claude/working-with-messages

Handling stop reasons

https://platform.claude.com/docs/en/build-with-claude/handling-stop-reasons

Prompting best practices

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices

Model capabilities

Extended thinking

https://platform.claude.com/docs/en/build-with-claude/extended-thinking

Adaptive thinking

https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking

https://platform.claude.com/docs/en/build-with-claude/effort

Fast mode (beta: research preview)

https://platform.claude.com/docs/en/build-with-claude/fast-mode

Structured outputs

https://platform.claude.com/docs/en/build-with-claude/structured-outputs

https://platform.claude.com/docs/en/build-with-claude/citations

Streaming Messages

https://platform.claude.com/docs/en/build-with-claude/streaming

Batch processing

https://platform.claude.com/docs/en/build-with-claude/batch-processing

PDF support

https://platform.claude.com/docs/en/build-with-claude/pdf-support

Search results

https://platform.claude.com/docs/en/build-with-claude/search-results

Multilingual support

https://platform.claude.com/docs/en/build-with-claude/multilingual-support

https://platform.claude.com/docs/en/build-with-claude/embeddings

https://platform.claude.com/docs/en/build-with-claude/vision

https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview

How to implement tool use

https://platform.claude.com/docs/en/agents-and-tools/tool-use/implement-tool-use

Web search tool

https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool

Web fetch tool

https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-fetch-tool

Code execution tool

https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool

Memory tool

https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool

https://platform.claude.com/docs/en/agents-and-tools/tool-use/bash-tool

Computer use tool

https://platform.claude.com/docs/en/agents-and-tools/tool-use/computer-use-tool

Text editor tool

https://platform.claude.com/docs/en/agents-and-tools/tool-use/text-editor-tool

Tool infrastructure

Tool search

https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool

Programmatic tool calling

https://platform.claude.com/docs/en/agents-and-tools/tool-use/programmatic-tool-calling

Fine-grained tool streaming

https://platform.claude.com/docs/en/agents-and-tools/tool-use/fine-grained-tool-streaming

Context management

Context windows

https://platform.claude.com/docs/en/build-with-claude/context-windows

https://platform.claude.com/docs/en/build-with-claude/compaction

Context editing

https://platform.claude.com/docs/en/build-with-claude/context-editing

Prompt caching

https://platform.claude.com/docs/en/build-with-claude/prompt-caching

Token counting

https://platform.claude.com/docs/en/build-with-claude/token-counting

Files & assets

https://platform.claude.com/docs/en/build-with-claude/files

Agent Skills

https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview

https://platform.claude.com/docs/en/agents-and-tools/agent-skills/quickstart

Best practices

https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices

Skills for enterprise

https://platform.claude.com/docs/en/agents-and-tools/agent-skills/enterprise

Using Skills with the API

https://platform.claude.com/docs/en/build-with-claude/skills-guide

https://platform.claude.com/docs/en/agent-sdk/overview

https://platform.claude.com/docs/en/agent-sdk/quickstart

How the agent loop works

https://platform.claude.com/docs/en/agent-sdk/agent-loop

Core concepts

SDK references

MCP in the API

MCP connector

https://platform.claude.com/docs/en/agents-and-tools/mcp-connector

Remote MCP servers

https://platform.claude.com/docs/en/agents-and-tools/remote-mcp-servers

Claude on 3rd-party platforms

Amazon Bedrock

https://platform.claude.com/docs/en/build-with-claude/claude-on-amazon-bedrock

Microsoft Foundry

https://platform.claude.com/docs/en/build-with-claude/claude-in-microsoft-foundry

https://platform.claude.com/docs/en/build-with-claude/claude-on-vertex-ai

Prompt engineering

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview

Console prompting tools

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-tools

Test & evaluate

Define success and build evaluations

https://platform.claude.com/docs/en/test-and-evaluate/develop-tests

Using the Evaluation Tool

https://platform.claude.com/docs/en/test-and-evaluate/eval-tool

Reducing latency

https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/reduce-latency

Strengthen guardrails

Reduce hallucinations

https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/reduce-hallucinations

Increase output consistency

https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/increase-consistency

Mitigate jailbreaks

https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/mitigate-jailbreaks

Streaming refusals

https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/handle-streaming-refusals

Reduce prompt leak

https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/reduce-prompt-leak

Administration and monitoring

Admin API overview

https://platform.claude.com/docs/en/build-with-claude/administration-api

Data residency

https://platform.claude.com/docs/en/build-with-claude/data-residency

https://platform.claude.com/docs/en/build-with-claude/workspaces

Usage and Cost API

https://platform.claude.com/docs/en/build-with-claude/usage-cost-api

Claude Code Analytics API

https://platform.claude.com/docs/en/build-with-claude/claude-code-analytics-api

Zero Data Retention

https://platform.claude.com/docs/en/build-with-claude/zero-data-retention

https://platform.claude.com/

https://platform.claude.com/login

Build with Claude

Prompting best practices

https://platform.claude.com/docs

https://x.com/claudeai

https://www.linkedin.com/showcase/claude

https://instagram.com/claudeai

https://claude.com/solutions/agents

Code modernization

https://claude.com/solutions/code-modernization

https://claude.com/solutions/coding

Customer support

https://claude.com/solutions/customer-support

https://claude.com/solutions/education

Financial services

https://claude.com/solutions/financial-services

https://claude.com/solutions/government

Life sciences

https://claude.com/solutions/life-sciences

Amazon Bedrock

https://claude.com/partners/amazon-bedrock

Google Cloud's Vertex AI

https://claude.com/partners/google-cloud-vertex-ai

https://claude.com/blog

https://claude.ai/catalog/artifacts

https://www.anthropic.com/learn

https://claude.com/resources/use-cases

https://claude.com/partners/mcp

Customer stories

https://claude.com/customers

Engineering at Anthropic

https://www.anthropic.com/engineering

https://www.anthropic.com/events

Powered by Claude

https://claude.com/partners/powered-by-claude

Service partners

https://claude.com/partners/services

Startups program

https://claude.com/programs/startups

https://www.anthropic.com/company

https://www.anthropic.com/careers

Economic Futures

https://www.anthropic.com/economic-futures

https://www.anthropic.com/research

https://www.anthropic.com/news

Responsible Scaling Policy

https://www.anthropic.com/news/announcing-our-updated-responsible-scaling-policy

Security and compliance

https://trust.anthropic.com/

Transparency

https://www.anthropic.com/transparency

https://claude.com/blog

https://claude.ai/catalog/artifacts

https://www.anthropic.com/learn

https://claude.com/resources/use-cases

https://claude.com/partners/mcp

Customer stories

https://claude.com/customers

Engineering at Anthropic

https://www.anthropic.com/engineering

https://www.anthropic.com/events

Powered by Claude

https://claude.com/partners/powered-by-claude

Service partners

https://claude.com/partners/services

Startups program

https://claude.com/programs/startups

Help and security

Availability

https://www.anthropic.com/supported-countries

https://status.claude.com/

https://support.claude.com/

https://www.anthropic.com/discord

Terms and policies

Privacy policy

https://www.anthropic.com/legal/privacy

Responsible disclosure policy

https://www.anthropic.com/responsible-disclosure-policy

Terms of service: Commercial

https://www.anthropic.com/legal/commercial-terms

Terms of service: Consumer

https://www.anthropic.com/legal/consumer-terms

Usage policy

https://www.anthropic.com/legal/aup

Build with Claude

Prompting best practices

Comprehensive guide to prompt engineering techniques for Claude's latest models, covering clarity, examples, XML structuring, thinking, and agentic systems.

This is the single reference for prompt engineering with Claude's latest models, including Claude Opus 4.6, Claude Sonnet 4.6, and Claude Haiku 4.5. It covers foundational techniques, output control, tool use, thinking, and agentic systems. Jump to the section that matches your situation.

For an overview of model capabilities, see the

models overview

https://platform.claude.com/docs/en/about-claude/models/overview

. For details on what's new in Claude 4.6, see

What's new in Claude 4.6

https://platform.claude.com/docs/en/about-claude/models/whats-new-claude-4-6

. For migration guidance, see the

Migration guide

https://platform.claude.com/docs/en/about-claude/models/migration-guide

General principles

Be clear and direct

Claude responds well to clear, explicit instructions. Being specific about your desired output can help enhance results. If you want "above and beyond" behavior, explicitly request it rather than relying on the model to infer this from vague prompts.

Think of Claude as a brilliant but new employee who lacks context on your norms and workflows. The more precisely you explain what you want, the better the result.

#### Golden rule:

Show your prompt to a colleague with minimal context on the task and ask them to follow it. If they'd be confused, Claude will be too.

Be specific about the desired output format and constraints.

Provide instructions as sequential steps using numbered lists or bullet points when the order or completeness of steps matters.

Example: Creating an analytics dashboard

Add context to improve performance

Providing context or motivation behind your instructions, such as explaining to Claude why such behavior is important, can help Claude better understand your goals and deliver more targeted responses.

Example: Formatting preferences

Claude is smart enough to generalize from the explanation.

Use examples effectively

Examples are one of the most reliable ways to steer Claude's output format, tone, and structure. A few well-crafted examples (known as few-shot or multishot prompting) can dramatically improve accuracy and consistency.

#### When adding examples, make them:

Mirror your actual use case closely.

Cover edge cases and vary enough that Claude doesn't pick up unintended patterns.

#### Structured:

Wrap examples in

tags (multiple examples in

tags) so Claude can distinguish them from instructions.

Include 3–5 examples for best results. You can also ask Claude to evaluate your examples for relevance and diversity, or to generate additional ones based on your initial set.

Structure prompts with XML tags

XML tags help Claude parse complex prompts unambiguously, especially when your prompt mixes instructions, context, examples, and variable inputs. Wrapping each type of content in its own tag (e.g.

<instructions>

) reduces misinterpretation.

#### Best practices:

Use consistent, descriptive tag names across your prompts.

Nest tags when content has a natural hierarchy (documents inside

<documents>

, each inside

<document index="n">

Give Claude a role

Setting a role in the system prompt focuses Claude's behavior and tone for your use case. Even a single sentence makes a difference:

import anthropic

client = anthropic.Anthropic()

message = client.messages.create(
    model="claude-opus-4-6",
    max\_tokens=1024,
    system="You are a helpful coding assistant specializing in Python.",
    messages=\[
        {"role": "user", "content": "How do I sort a list of dictionaries by key?"}
    \],
)
print(message.content)

Long context prompting

When working with large documents or data-rich inputs (20k+ tokens), structure your prompt carefully to get the best results:

Put longform data at the top

: Place your long documents and inputs near the top of your prompt, above your query, instructions, and examples. This can significantly improve performance across all models. Queries at the end can improve response quality by up to 30% in tests, especially with complex, multi-document inputs.

Structure document content and metadata with XML tags

: When using multiple documents, wrap each document in

<document\_content>

(and other metadata) subtags for clarity.

Example multi-document structure

Ground responses in quotes

: For long document tasks, ask Claude to quote relevant parts of the documents first before carrying out its task. This helps Claude cut through the noise of the rest of the document's contents.

Example quote extraction

Model self-knowledge

If you would like Claude to identify itself correctly in your application or use specific API strings:

Sample prompt for model identity

The assistant is Claude, created by Anthropic. The current model is Claude Opus 4.6.

#### For LLM-powered apps that need to specify model strings:

Sample prompt for model string

When an LLM is needed, please default to Claude Opus 4.6 unless the user requests otherwise. The exact model string for Claude Opus 4.6 is claude-opus-4-6.

Output and formatting

Communication style and verbosity

Claude's latest models have a more concise and natural communication style compared to previous models:

#### More direct and grounded:

Provides fact-based progress reports rather than self-celebratory updates

#### More conversational:

Slightly more fluent and colloquial, less machine-like

#### Less verbose:

May skip detailed summaries for efficiency unless prompted otherwise

This means Claude may skip verbal summaries after tool calls, jumping directly to the next action. If you prefer more visibility into its reasoning:

Sample prompt

After completing a task that involves tool use, provide a quick summary of the work you've done.

Control the format of responses

#### There are a few particularly effective ways to steer output formatting:

Tell Claude what to do instead of what not to do

Instead of: "Do not use markdown in your response"

Try: "Your response should be composed of smoothly flowing prose paragraphs."

Use XML format indicators

Try: "Write the prose sections of your response in <smoothly\_flowing\_prose\_paragraphs> tags."

Match your prompt style to the desired output

The formatting style used in your prompt may influence Claude's response style. If you are still experiencing steerability issues with output formatting, try matching your prompt style to your desired output style as closely as possible. For example, removing markdown from your prompt can reduce the volume of markdown in the output.

Use detailed prompts for specific formatting preferences

#### For more control over markdown and formatting usage, provide explicit guidance:

Sample prompt to minimize markdown

<avoid\_excessive\_markdown\_and\_bullet\_points>
When writing reports, documents, technical explanations, analyses, or any long-form content, write in clear, flowing prose using complete paragraphs and sentences. Use standard paragraph breaks for organization and reserve markdown primarily for \`inline code\`, code blocks (\`\`\`...\`\`\`), and simple headings (###, and ###). Avoid using \*\*bold\*\* and \*italics\*.

DO NOT use ordered lists (1. ...) or unordered lists (\*) unless : a) you're presenting truly discrete items where a list format is the best option, or b) the user explicitly requests a list or ranking

Instead of listing items with bullets or numbers, incorporate them naturally into sentences. This guidance applies especially to technical writing. Using prose instead of excessive formatting will improve user satisfaction. NEVER output a series of overly short bullet points.

Your goal is readable, flowing text that guides the reader naturally through ideas rather than fragmenting information into isolated points.
</avoid\_excessive\_markdown\_and\_bullet\_points>

LaTeX output

Claude Opus 4.6 defaults to LaTeX for mathematical expressions, equations, and technical explanations. If you prefer plain text, add the following instructions to your prompt:

Sample prompt

Format your response in plain text only. Do not use LaTeX, MathJax, or any markup notation such as \( \), $, or \frac{}{}. Write all math expressions using standard text characters (e.g., "/" for division, "\*" for multiplication, and "^" for exponents).

Document creation

Claude's latest models excel at creating presentations, animations, and visual documents with impressive creative flair and strong instruction following. The models produce polished, usable output on the first try in most cases.

#### For best results with document creation:

Sample prompt

Create a professional presentation on \[topic\]. Include thoughtful design elements, visual hierarchy, and engaging animations where appropriate.

Migrating away from prefilled responses

Starting with Claude 4.6 models, prefilled responses on the last assistant turn are no longer supported. Model intelligence and instruction following has advanced such that most use cases of prefill no longer require it. Existing models will continue to support prefills, and adding assistant messages elsewhere in the conversation is not affected.

#### Here are common prefill scenarios and how to migrate away from them:

Controlling output formatting

Eliminating preambles

Avoiding bad refusals

Continuations

Context hydration and role consistency

Claude's latest models are trained for precise instruction following and benefit from explicit direction to use specific tools. If you say "can you suggest some changes," Claude will sometimes provide suggestions rather than implementing them, even if making changes might be what you intended.

#### For Claude to take action, be more explicit:

Example: Explicit instructions

To make Claude more proactive about taking action by default, you can add this to your system prompt:

Sample prompt for proactive action

<default\_to\_action>
By default, implement changes rather than only suggesting them. If the user's intent is unclear, infer the most useful likely action and proceed, using tools to discover any missing details instead of guessing. Try to infer the user's intent about whether a tool call (e.g., file edit or read) is intended or not, and act accordingly.
</default\_to\_action>

On the other hand, if you want the model to be more hesitant by default, less prone to jumping straight into implementations, and only take action if requested, you can steer this behavior with a prompt like the below:

Sample prompt for conservative action

<do\_not\_act\_before\_instructions>
Do not jump into implementatation or changes files unless clearly instructed to make changes. When the user's intent is ambiguous, default to providing information, doing research, and providing recommendations rather than taking action. Only proceed with edits, modifications, or implementations when the user explicitly requests them.
</do\_not\_act\_before\_instructions>

Claude Opus 4.5 and Claude Opus 4.6 are also more responsive to the system prompt than previous models. If your prompts were designed to reduce undertriggering on tools or skills, these models may now overtrigger. The fix is to dial back any aggressive language. Where you might have said "CRITICAL: You MUST use this tool when...", you can use more normal prompting like "Use this tool when...".

Optimize parallel tool calling

#### Claude's latest models excel at parallel tool execution. These models will:

Run multiple speculative searches during research

Read several files at once to build context faster

Execute bash commands in parallel (which can even bottleneck system performance)

This behavior is easily steerable. While the model has a high success rate in parallel tool calling without prompting, you can boost this to ~100% or adjust the aggression level:

Sample prompt for maximum parallel efficiency

<use\_parallel\_tool\_calls>
If you intend to call multiple tools and there are no dependencies between the tool calls, make all of the independent tool calls in parallel. Prioritize calling tools simultaneously whenever the actions can be done in parallel rather than sequentially. For example, when reading 3 files, run 3 tool calls in parallel to read all 3 files into context at the same time. Maximize use of parallel tool calls where possible to increase speed and efficiency. However, if some tool calls depend on previous calls to inform dependent values like the parameters, do NOT call these tools in parallel and instead call them sequentially. Never use placeholders or guess missing parameters in tool calls.
</use\_parallel\_tool\_calls>

Sample prompt to reduce parallel execution

Execute operations sequentially with brief pauses between each step to ensure stability.

Thinking and reasoning

Overthinking and excessive thoroughness

Claude Opus 4.6 does significantly more upfront exploration than previous models, especially at higher

settings. This initial work often helps to optimize the final results, but the model may gather extensive context or pursue multiple threads of research without being prompted. If your prompts previously encouraged the model to be more thorough, you should tune that guidance for Claude Opus 4.6:

Replace blanket defaults with more targeted instructions.

Instead of "Default to using \[tool\]," add guidance like "Use \[tool\] when it would enhance your understanding of the problem."

Remove over-prompting.

Tools that undertriggered in previous models are likely to trigger appropriately now. Instructions like "If in doubt, use \[tool\]" will cause overtriggering.

Use effort as a fallback.

If Claude continues to be overly aggressive, use a lower setting for

In some cases, Claude Opus 4.6 may think extensively, which can inflate thinking tokens and slow down responses. If this behavior is undesirable, you can add explicit instructions to constrain its reasoning, or you can lower the

setting to reduce overall thinking and token usage.

Sample prompt

When you're deciding how to approach a problem, choose an approach and commit to it. Avoid revisiting decisions unless you encounter new information that directly contradicts your reasoning. If you're weighing two approaches, pick one and see it through. You can always course-correct later if the chosen approach fails.

For Claude Sonnet 4.6 specifically, switching from adaptive to extended thinking with a

budget\_tokens

cap provides a hard ceiling on thinking costs while preserving quality.

Leverage thinking & interleaved thinking capabilities

Claude's latest models offer thinking capabilities that can be especially helpful for tasks involving reflection after tool use or complex multi-step reasoning. You can guide its initial or interleaved thinking for better results.

Claude Opus 4.6 uses

adaptive thinking

https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking

thinking: {type: "adaptive"}

), where Claude dynamically decides when and how much to think. Claude Sonnet 4.6 supports both adaptive thinking and manual extended thinking with

interleaved mode

https://platform.claude.com/docs/en/build-with-claude/extended-thinking#interleaved-thinking

. Claude calibrates its thinking based on two factors: the

parameter and query complexity. Higher effort elicits more thinking, and more complex queries do the same. On easier queries that don't require thinking, the model responds directly. In internal evaluations, adaptive thinking reliably drives better performance than extended thinking. Consider moving to adaptive thinking to get the most intelligent responses.

For Sonnet 4.6, consider trying adaptive thinking for workloads that require agentic behavior such as multi-step tool use, complex coding tasks, and long-horizon agent loops. If adaptive thinking doesn't fit your use case, manual extended thinking with interleaved mode remains supported. Older models use manual thinking mode with

budget\_tokens

#### You can guide Claude's thinking behavior:

Example prompt

After receiving tool results, carefully reflect on their quality and determine optimal next steps before proceeding. Use your thinking to plan and iterate based on this new information, and then take the best next action.

The triggering behavior for adaptive thinking is promptable. If you find the model thinking more often than you'd like, which can happen with large or complex system prompts, add guidance to steer it:

Sample prompt

Extended thinking adds latency and should only be used when it will meaningfully improve answer quality - typically for problems that require multi-step reasoning. When in doubt, respond directly.

If you are migrating from

extended thinking

https://platform.claude.com/docs/en/build-with-claude/extended-thinking

budget\_tokens

, replace your thinking configuration and move budget control to

Before (extended thinking, older models)

client.messages.create(
    model="claude-sonnet-4-5-20250929",
    max\_tokens=64000,
    thinking={"type": "enabled", "budget\_tokens": 32000},
    messages=\[{"role": "user", "content": "..."}\],
)

After (adaptive thinking)

client.messages.create(
    model="claude-opus-4-6",
    max\_tokens=64000,
    thinking={"type": "adaptive"},
    output\_config={"effort": "high"},  # or max, medium, low
    messages=\[{"role": "user", "content": "..."}\],
)

If you are not using extended thinking, no changes are required. Thinking is off by default when you omit the

Prefer general instructions over prescriptive steps.

A prompt like "think thoroughly" often produces better reasoning than a hand-written step-by-step plan. Claude's reasoning frequently exceeds what a human would prescribe.

Multishot examples work with thinking.

tags inside your few-shot examples to show Claude the reasoning pattern. It will generalize that style to its own extended thinking blocks.

Manual CoT as a fallback.

When thinking is off, you can still encourage step-by-step reasoning by asking Claude to think through the problem. Use structured tags like

to cleanly separate reasoning from the final output.

Ask Claude to self-check.

Append something like "Before you finish, verify your answer against \[test criteria\]." This catches errors reliably, especially for coding and math.

When extended thinking is disabled, Claude Opus 4.5 is particularly sensitive to the word "think" and its variants. Consider using alternatives like "consider," "evaluate," or "reason through" in those cases.

For more information on thinking capabilities, see

Extended thinking

https://platform.claude.com/docs/en/build-with-claude/extended-thinking

Adaptive thinking

https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking

Agentic systems

Long-horizon reasoning and state tracking

Claude's latest models excel at long-horizon reasoning tasks with exceptional state tracking capabilities. Claude maintains orientation across extended sessions by focusing on incremental progress, making steady advances on a few things at a time rather than attempting everything at once. This capability especially emerges over multiple context windows or task iterations, where Claude can work on a complex task, save the state, and continue with a fresh context window.

Context awareness and multi-window workflows

Claude 4.6 and Claude 4.5 models feature

context awareness

https://platform.claude.com/docs/en/build-with-claude/context-windows#context-awareness-in-claude-sonnet-4-6-sonnet-4-5-and-haiku-4-5

, enabling the model to track its remaining context window (i.e. "token budget") throughout a conversation. This enables Claude to execute tasks and manage context more effectively by understanding how much space it has to work.

#### Managing context limits:

If you are using Claude in an agent harness that compacts context or allows saving context to external files (like in Claude Code), consider adding this information to your prompt so Claude can behave accordingly. Otherwise, Claude may sometimes naturally try to wrap up work as it approaches the context limit. Below is an example prompt:

Sample prompt

Your context window will be automatically compacted as it approaches its limit, allowing you to continue working indefinitely from where you left off. Therefore, do not stop tasks early due to token budget concerns. As you approach your token budget limit, save your current progress and state to memory before the context window refreshes. Always be as persistent and autonomous as possible and complete tasks fully, even if the end of your budget is approaching. Never artificially stop any task early regardless of the context remaining.

memory tool

https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool

pairs naturally with context awareness for seamless context transitions.

Multi-context window workflows

#### For tasks spanning multiple context windows:

Use a different prompt for the very first context window

: Use the first context window to set up a framework (write tests, create setup scripts), then use future context windows to iterate on a todo-list.

Have the model write tests in a structured format

: Ask Claude to create tests before starting work and keep track of them in a structured format (e.g.,

). This leads to better long-term ability to iterate. Remind Claude of the importance of tests: "It is unacceptable to remove or edit tests because this could lead to missing or buggy functionality."

Set up quality of life tools

: Encourage Claude to create setup scripts (e.g.,

) to gracefully start servers, run test suites, and linters. This prevents repeated work when continuing from a fresh context window.

Starting fresh vs compacting

: When a context window is cleared, consider starting with a brand new context window rather than using compaction. Claude's latest models are extremely effective at discovering state from the local filesystem. In some cases, you may want to take advantage of this over compaction. Be prescriptive about how it should start:

"Call pwd; you can only read and write files in this directory."

"Review progress.txt, tests.json, and the git logs."

"Manually run through a fundamental integration test before moving on to implementing new features."

Provide verification tools

: As the length of autonomous tasks grows, Claude needs to verify correctness without continuous human feedback. Tools like Playwright MCP server or computer use capabilities for testing UIs are helpful.

Encourage complete usage of context

: Prompt Claude to efficiently complete components before moving on:

Sample prompt

This is a very long task, so it may be beneficial to plan out your work clearly. It's encouraged to spend your entire output context working on the task - just make sure you don't run out of context with significant uncommitted work. Continue working systematically until you have completed this task.

State management best practices

Use structured formats for state data

: When tracking structured information (like test results or task status), use JSON or other structured formats to help Claude understand schema requirements

Use unstructured text for progress notes

: Freeform progress notes work well for tracking general progress and context

Use git for state tracking

: Git provides a log of what's been done and checkpoints that can be restored. Claude's latest models perform especially well in using git to track state across multiple sessions.

Emphasize incremental progress

: Explicitly ask Claude to keep track of its progress and focus on incremental work

Example: State tracking

Balancing autonomy and safety

Without guidance, Claude Opus 4.6 may take actions that are difficult to reverse or affect shared systems, such as deleting files, force-pushing, or posting to external services. If you want Claude Opus 4.6 to confirm before taking potentially risky actions, add guidance to your prompt:

Sample prompt

Consider the reversibility and potential impact of your actions. You are encouraged to take local, reversible actions like editing files or running tests, but for actions that are hard to reverse, affect shared systems, or could be destructive, ask the user before proceeding.

Examples of actions that warrant confirmation:
- Destructive operations: deleting files or branches, dropping database tables, rm -rf
- Hard to reverse operations: git push --force, git reset --hard, amending published commits
- Operations visible to others: pushing code, commenting on PRs/issues, sending messages, modifying shared infrastructure

When encountering obstacles, do not use destructive actions as a shortcut. For example, don't bypass safety checks (e.g. --no-verify) or discard unfamiliar files that may be in-progress work.

Research and information gathering

Claude's latest models demonstrate exceptional agentic search capabilities and can find and synthesize information from multiple sources effectively. For optimal research results:

Provide clear success criteria

: Define what constitutes a successful answer to your research question

Encourage source verification

: Ask Claude to verify information across multiple sources

For complex research tasks, use a structured approach

Sample prompt for complex research

Search for this information in a structured way. As you gather data, develop several competing hypotheses. Track your confidence levels in your progress notes to improve calibration. Regularly self-critique your approach and plan. Update a hypothesis tree or research notes file to persist information and provide transparency. Break down this complex research task systematically.

This structured approach allows Claude to find and synthesize virtually any piece of information and iteratively critique its findings, no matter the size of the corpus.

Subagent orchestration

Claude's latest models demonstrate significantly improved native subagent orchestration capabilities. These models can recognize when tasks would benefit from delegating work to specialized subagents and do so proactively without requiring explicit instruction.

#### To take advantage of this behavior:

Ensure well-defined subagent tools

: Have subagent tools available and described in tool definitions

Let Claude orchestrate naturally

: Claude will delegate appropriately without explicit instruction

Watch for overuse

: Claude Opus 4.6 has a strong predilection for subagents and may spawn them in situations where a simpler, direct approach would suffice. For example, the model may spawn subagents for code exploration when a direct grep call is faster and sufficient.

If you're seeing excessive subagent use, add explicit guidance about when subagents are and aren't warranted:

Sample prompt for subagent usage

Use subagents when tasks can run in parallel, require isolated context, or involve independent workstreams that don't need to share state. For simple tasks, sequential operations, single-file edits, or tasks where you need to maintain context across steps, work directly rather than delegating.

Chain complex prompts

With adaptive thinking and subagent orchestration, Claude handles most multi-step reasoning internally. Explicit prompt chaining (breaking a task into sequential API calls) is still useful when you need to inspect intermediate outputs or enforce a specific pipeline structure.

The most common chaining pattern is

self-correction

: generate a draft → have Claude review it against criteria → have Claude refine based on the review. Each step is a separate API call so you can log, evaluate, or branch at any point.

Reduce file creation in agentic coding

Claude's latest models may sometimes create new files for testing and iteration purposes, particularly when working with code. This approach allows Claude to use files, especially python scripts, as a 'temporary scratchpad' before saving its final output. Using temporary files can improve outcomes particularly for agentic coding use cases.

If you'd prefer to minimize net new file creation, you can instruct Claude to clean up after itself:

Sample prompt

If you create any temporary new files, scripts, or helper files for iteration, clean up these files by removing them at the end of the task.

Overeagerness

Claude Opus 4.5 and Claude Opus 4.6 have a tendency to overengineer by creating extra files, adding unnecessary abstractions, or building in flexibility that wasn't requested. If you're seeing this undesired behavior, add specific guidance to keep solutions minimal.

#### For example:

Sample prompt to minimize overengineering

Avoid over-engineering. Only make changes that are directly requested or clearly necessary. Keep solutions simple and focused:

- Scope: Don't add features, refactor code, or make "improvements" beyond what was asked. A bug fix doesn't need surrounding code cleaned up. A simple feature doesn't need extra configurability.

- Documentation: Don't add docstrings, comments, or type annotations to code you didn't change. Only add comments where the logic isn't self-evident.

- Defensive coding: Don't add error handling, fallbacks, or validation for scenarios that can't happen. Trust internal code and framework guarantees. Only validate at system boundaries (user input, external APIs).

- Abstractions: Don't create helpers, utilities, or abstractions for one-time operations. Don't design for hypothetical future requirements. The right amount of complexity is the minimum needed for the current task.

Avoid focusing on passing tests and hard-coding

Claude can sometimes focus too heavily on making tests pass at the expense of more general solutions, or may use workarounds like helper scripts for complex refactoring instead of using standard tools directly. To prevent this behavior and ensure robust, generalizable solutions:

Sample prompt

Please write a high-quality, general-purpose solution using the standard tools available. Do not create helper scripts or workarounds to accomplish the task more efficiently. Implement a solution that works correctly for all valid inputs, not just the test cases. Do not hard-code values or create solutions that only work for specific test inputs. Instead, implement the actual logic that solves the problem generally.

Focus on understanding the problem requirements and implementing the correct algorithm. Tests are there to verify correctness, not to define the solution. Provide a principled implementation that follows best practices and software design principles.

If the task is unreasonable or infeasible, or if any of the tests are incorrect, please inform me rather than working around them. The solution should be robust, maintainable, and extendable.

Minimizing hallucinations in agentic coding

Claude's latest models are less prone to hallucinations and give more accurate, grounded, intelligent answers based on the code. To encourage this behavior even more and minimize hallucinations:

Sample prompt

<investigate\_before\_answering>
Never speculate about code you have not opened. If the user references a specific file, you MUST read the file before answering. Make sure to investigate and read relevant files BEFORE answering questions about the codebase. Never make any claims about code before investigating unless you are certain of the correct answer - give grounded and hallucination-free answers.
</investigate\_before\_answering>

Capability-specific tips

Improved vision capabilities

Claude Opus 4.5 and Claude Opus 4.6 have improved vision capabilities compared to previous Claude models. They perform better on image processing and data extraction tasks, particularly when there are multiple images present in context. These improvements carry over to computer use, where the models can more reliably interpret screenshots and UI elements. You can also use these models to analyze videos by breaking them up into frames.

One technique that has proven effective to further boost performance is to give Claude a crop tool or

https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview

. Testing has shown consistent uplift on image evaluations when Claude is able to "zoom" in on relevant regions of an image. Anthropic has created a

cookbook for the crop tool

https://platform.claude.com/cookbook/multimodal-crop-tool

Frontend design

Claude Opus 4.5 and Claude Opus 4.6 excel at building complex, real-world web applications with strong frontend design. However, without guidance, models can default to generic patterns that create what users call the "AI slop" aesthetic. To create distinctive, creative frontends that surprise and delight:

For a detailed guide on improving frontend design, see the blog post on

improving frontend design through skills

https://www.claude.com/blog/improving-frontend-design-through-skills

#### Here's a system prompt snippet you can use to encourage better frontend design:

Sample prompt for frontend aesthetics

<frontend\_aesthetics>
You tend to converge toward generic, "on distribution" outputs. In frontend design, this creates what users call the "AI slop" aesthetic. Avoid this: make creative, distinctive frontends that surprise and delight.

Focus on:
- Typography: Choose fonts that are beautiful, unique, and interesting. Avoid generic fonts like Arial and Inter; opt instead for distinctive choices that elevate the frontend's aesthetics.
- Color & Theme: Commit to a cohesive aesthetic. Use CSS variables for consistency. Dominant colors with sharp accents outperform timid, evenly-distributed palettes. Draw from IDE themes and cultural aesthetics for inspiration.
- Motion: Use animations for effects and micro-interactions. Prioritize CSS-only solutions for HTML. Use Motion library for React when available. Focus on high-impact moments: one well-orchestrated page load with staggered reveals (animation-delay) creates more delight than scattered micro-interactions.
- Backgrounds: Create atmosphere and depth rather than defaulting to solid colors. Layer CSS gradients, use geometric patterns, or add contextual effects that match the overall aesthetic.

Avoid generic AI-generated aesthetics:
- Overused font families (Inter, Roboto, Arial, system fonts)
- Clichéd color schemes (particularly purple gradients on white backgrounds)
- Predictable layouts and component patterns
- Cookie-cutter design that lacks context-specific character

Interpret creatively and make unexpected choices that feel genuinely designed for the context. Vary between light and dark themes, different fonts, different aesthetics. You still tend to converge on common choices (Space Grotesk, for example) across generations. Avoid this: it is critical that you think outside the box!
</frontend\_aesthetics>

You can also refer to the

full skill definition

https://github.com/anthropics/claude-code/blob/main/plugins/frontend-design/skills/frontend-design/SKILL.md

Migration considerations

#### When migrating to Claude 4.6 models from earlier generations:

Be specific about desired behavior

: Consider describing exactly what you'd like to see in the output.

Frame your instructions with modifiers

: Adding modifiers that encourage Claude to increase the quality and detail of its output can help better shape Claude's performance. For example, instead of "Create an analytics dashboard", use "Create an analytics dashboard. Include as many relevant features and interactions as possible. Go beyond the basics to create a fully-featured implementation."

Request specific features explicitly

: Animations and interactive elements should be requested explicitly when desired.

Update thinking configuration

: Claude 4.6 models use

adaptive thinking

https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking

thinking: {type: "adaptive"}

) instead of manual thinking with

budget\_tokens

effort parameter

https://platform.claude.com/docs/en/build-with-claude/effort

to control thinking depth.

Migrate away from prefilled responses

: Prefilled responses on the last assistant turn are deprecated starting with Claude 4.6 models. See

Migrating away from prefilled responses

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#migrating-away-from-prefilled-responses

for detailed guidance on alternatives.

Tune anti-laziness prompting

: If your prompts previously encouraged the model to be more thorough or use tools more aggressively, dial back that guidance. Claude 4.6 models are significantly more proactive and may overtrigger on instructions that were needed for previous models.

For detailed migration steps, see the

Migration guide

https://platform.claude.com/docs/en/about-claude/models/migration-guide

Migrating from Claude Sonnet 4.5 to Claude Sonnet 4.6

Claude Sonnet 4.6 defaults to an effort level of

, in contrast to Claude Sonnet 4.5 which had no effort parameter. Consider adjusting the effort parameter as you migrate from Claude Sonnet 4.5 to Claude Sonnet 4.6. If not explicitly set, you may experience higher latency with the default effort level.

#### Recommended effort settings:

for most applications

for high-volume or latency-sensitive workloads

Set a large max output token budget (64k tokens recommended) at medium or high effort to give the model room to think and act

#### When to use Opus 4.6 instead:

For the hardest, longest-horizon problems (large-scale code migrations, deep research, extended autonomous work), Opus 4.6 remains the right choice. Sonnet 4.6 is optimized for workloads where fast turnaround and cost efficiency matter most.

If you're not using extended thinking

If you're not using extended thinking on Claude Sonnet 4.5, you can continue without it on Claude Sonnet 4.6. You should explicitly set effort to the level appropriate for your use case. At

effort with thinking disabled, you can expect similar or better performance relative to Claude Sonnet 4.5 with no extended thinking.

client.messages.create(
    model="claude-sonnet-4-6",
    max\_tokens=8192,
    thinking={"type": "disabled"},
    output\_config={"effort": "low"},
    messages=\[{"role": "user", "content": "..."}\],
)

If you're using extended thinking

If you're using extended thinking on Claude Sonnet 4.5, it continues to be supported on Claude Sonnet 4.6 with no changes needed to your thinking configuration. Consider keeping a thinking budget around 16k tokens. In practice, most tasks don't use that much, but it provides headroom for harder problems without risk of runaway token usage.

For coding use cases

(agentic coding, tool-heavy workflows, code generation):

effort. If you find latency is too high, consider reducing effort to

. If you need higher intelligence, consider increasing effort to

or migrating to Opus 4.6.

client.messages.create(
    model="claude-sonnet-4-6",
    max\_tokens=16384,
    thinking={"type": "enabled", "budget\_tokens": 16384},
    output\_config={"effort": "medium"},
    messages=\[{"role": "user", "content": "..."}\],
)

For chat and non-coding use cases

(chat, content generation, search, classification):

effort with extended thinking. If you need more depth, increase effort to

client.messages.create(
    model="claude-sonnet-4-6",
    max\_tokens=8192,
    thinking={"type": "enabled", "budget\_tokens": 16384},
    output\_config={"effort": "low"},
    messages=\[{"role": "user", "content": "..."}\],
)

When to try adaptive thinking

The extended thinking paths above use

budget\_tokens

for predictable token usage. If your workload fits one of the following patterns, consider trying

adaptive thinking

https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking

#### Autonomous multi-step agents:

coding agents that turn requirements into working software, data analysis pipelines, and bug finding where the model runs independently across many steps. Adaptive thinking lets the model calibrate its reasoning per step, staying on path over longer trajectories. For these workloads, start at

effort. If latency or token usage is a concern, scale down to

#### Computer use agents:

Claude Sonnet 4.6 achieved best-in-class accuracy on computer use evaluations using adaptive mode.

#### Bimodal workloads:

a mix of easy and hard tasks where adaptive skips thinking on simple queries and reasons deeply on complex ones.

When using adaptive thinking, evaluate

effort on your tasks. The right level depends on your workload's tradeoff between quality, latency, and token usage.

client.messages.create(
    model="claude-sonnet-4-6",
    max\_tokens=64000,
    thinking={"type": "adaptive"},
    output\_config={"effort": "high"},
    messages=\[{"role": "user", "content": "..."}\],
)

Was this page helpful?

General principles

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#general-principles

Be clear and direct

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#be-clear-and-direct

Add context to improve performance

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#add-context-to-improve-performance

Use examples effectively

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#use-examples-effectively

Structure prompts with XML tags

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#structure-prompts-with-xml-tags

Give Claude a role

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role

Long context prompting

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#long-context-prompting

Model self-knowledge

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#model-self-knowledge

Output and formatting

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#output-and-formatting

Communication style and verbosity

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#communication-style-and-verbosity

Control the format of responses

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#control-the-format-of-responses

LaTeX output

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#la-te-x-output

Document creation

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#document-creation

Migrating away from prefilled responses

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#migrating-away-from-prefilled-responses

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#tool-use

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#tool-usage

Optimize parallel tool calling

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#optimize-parallel-tool-calling

Thinking and reasoning

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#thinking-and-reasoning

Overthinking and excessive thoroughness

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#overthinking-and-excessive-thoroughness

Leverage thinking & interleaved thinking capabilities

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#leverage-thinking-and-interleaved-thinking-capabilities

Agentic systems

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#agentic-systems

Long-horizon reasoning and state tracking

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#long-horizon-reasoning-and-state-tracking

Balancing autonomy and safety

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#balancing-autonomy-and-safety

Research and information gathering

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#research-and-information-gathering

Subagent orchestration

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#subagent-orchestration

Chain complex prompts

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#chain-complex-prompts

Reduce file creation in agentic coding

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#reduce-file-creation-in-agentic-coding

Overeagerness

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#overeagerness

Avoid focusing on passing tests and hard-coding

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#avoid-focusing-on-passing-tests-and-hard-coding

Minimizing hallucinations in agentic coding

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#minimizing-hallucinations-in-agentic-coding

Capability-specific tips

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#capability-specific-tips

Improved vision capabilities

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#improved-vision-capabilities

Frontend design

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#frontend-design

Migration considerations

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#migration-considerations

Migrating from Claude Sonnet 4.5 to Claude Sonnet 4.6

https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#migrating-from-claude-sonnet-4-5-to-claude-sonnet-4-6

